function myOuterFunc() {
    console.log("이 함수는 제가 밖에서 만들어온 함수입니다.");
}


// function myName() {
//     console.log("제 이름은" + " " + name + " " + "입니다.");
// }